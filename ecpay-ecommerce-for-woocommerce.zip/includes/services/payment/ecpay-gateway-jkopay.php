<?php

class Wooecpay_Gateway_Jkopay extends Wooecpay_Gateway_Base
{
    protected $payment_type;
    protected $min_amount;

    public function __construct()
    {
        $this->id                   = 'Wooecpay_Gateway_Jkopay';
        $this->payment_type         = 'DigitalPayment';
        $this->icon                 = plugins_url('images/icon.png', dirname(dirname( __FILE__ )) );
        $this->has_fields           = false;
        $this->method_title         = __('ECPay Jkopay', 'ecpay-ecommerce-for-woocommerce');
        $this->method_description   = '使用街口支付';

        $this->title                = __('ECPay Jkopay', 'ecpay-ecommerce-for-woocommerce');
        $this->description          = $this->get_option('description');
        $this->min_amount           = (int) $this->get_option('min_amount', 0);
        $this->max_amount           = (int) $this->get_option('max_amount', 0);

        $this->form_fields          = include WOOECPAY_PLUGIN_INCLUDE_DIR . '/config/payment/settings-gateway-jkopay.php' ;
        $this->init_settings();

        parent::__construct();

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function process_admin_options()
    {
        parent::process_admin_options();
    }

    public function is_available()
    {
        if ('yes' == $this->enabled && WC()->cart) {
            $total = $this->get_order_total();

            if ($total > 0) {
                if ($this->min_amount > 0 and $total < $this->min_amount) {
                    return false;
                }
                // 上限為 199999 元
                if ($this->max_amount > 0 && $total > $this->max_amount) {
                    return false;
                }
                if ($total > 199999) {
                    return false;
                }
            }
        }

        return parent::is_available();
    }

    public function process_payment($order_id){

        $order = wc_get_order($order_id);
        $order->add_order_note(__('Pay via ECPay Jkopay', 'ecpay-ecommerce-for-woocommerce'));
        wc_maybe_reduce_stock_levels($order_id);
        wc_release_stock_for_order($order);

        return [
            'result'   => 'success',
            'redirect' => $order->get_checkout_payment_url(true),
        ];
    }
}
